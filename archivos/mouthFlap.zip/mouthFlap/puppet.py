import tkinter as tk
from PIL import Image, ImageTk

# === Config ===
base_size = (300, 300)
scale_factor = 1.5
image_size = (int(base_size[0] * scale_factor), int(base_size[1] * scale_factor))

# === GUI setup ===
root = tk.Tk()
root.title("Hold-Space Puppet")
root.configure(bg='green')
root.geometry("640x480")

# === Load & prepare images ===
try:
    resample = Image.Resampling.LANCZOS
except AttributeError:
    resample = Image.LANCZOS

img_closed = Image.open("1.png").convert("RGBA").resize(image_size, resample)
img_open   = Image.open("2.png").convert("RGBA").resize(image_size, resample)

tk_closed = ImageTk.PhotoImage(img_closed, master=root)
tk_open   = ImageTk.PhotoImage(img_open,   master=root)

# === Initial state ===
label = tk.Label(root, image=tk_closed, bg='green', bd=0)
label.place(relx=0.5, rely=0.5, anchor=tk.CENTER)
last_key = None

# === Handlers ===
def mouth_open(event=None):
    label.config(image=tk_open)
    label.image = tk_open

def mouth_closed(event=None):
    label.config(image=tk_closed)
    label.image = tk_closed

def on_key(event):
    global last_key
    if len(event.char) == 1:
        last_key = event.char
    if event.keysym == 'Return' and last_key == 'c':
        root.destroy()

# === Bind keys ===
root.bind("<KeyPress-space>", mouth_open)
root.bind("<KeyRelease-space>", mouth_closed)
root.bind("<Key>", on_key)

# === Run ===
root.mainloop()
